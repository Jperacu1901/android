package com.example.actividadsensores

import android.media.AudioAttributes
import android.media.SoundPool
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.actividadsensores.R
import com.example.actividadsensores.ui.theme.ActividadSensoresTheme
import kotlin.math.abs
import kotlin.math.sqrt

class MainActivity : ComponentActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var gyroscope: Sensor? = null
    private var accelerometer: Sensor? = null

    private var offsetX by mutableFloatStateOf(0f)
    private var offsetY by mutableFloatStateOf(0f)
    private var accelerationForce by mutableFloatStateOf(0f)

    private lateinit var soundPool: SoundPool
    private var soundId: Int = 0
    private var streamId: Int = 0
    private var isPlayingSound = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(1)
            .setAudioAttributes(audioAttributes)
            .build()

        soundId = soundPool.load(this, R.raw.spin_sound, 1)

        enableEdgeToEdge()
        setContent {
            ActividadSensoresTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    GyroscopeIndicator(
                        x = offsetX,
                        y = offsetY,
                        acceleration = accelerationForce,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        gyroscope?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
        stopSpinSound()
    }

    override fun onDestroy() {
        super.onDestroy()
        soundPool.release()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        when (event?.sensor?.type) {
            Sensor.TYPE_GYROSCOPE -> {
                val rotX = event.values[0]
                val rotY = event.values[1]

                val angularSpeed = sqrt((rotX * rotX + rotY * rotY).toDouble()).toFloat()

                if (angularSpeed > 0.15f) {
                    playSpinSound()
                } else {
                    stopSpinSound()
                }

                val maxOffset = 130f
                offsetX = (offsetX + rotY * 20f).coerceIn(-maxOffset, maxOffset)
                offsetY = (offsetY + rotX * 20f).coerceIn(-maxOffset, maxOffset)
            }

            Sensor.TYPE_ACCELEROMETER -> {
                val ax = event.values[0]
                val ay = event.values[1]
                val az = event.values[2]

                val magnitude = sqrt((ax * ax + ay * ay + az * az).toDouble()).toFloat()
                accelerationForce = abs(magnitude - SensorManager.GRAVITY_EARTH)
            }
        }
    }

    private fun playSpinSound() {
        if (!isPlayingSound && soundId != 0) {
            streamId = soundPool.play(soundId, 1f, 1f, 1, -1, 1f)
            isPlayingSound = true
        }
    }

    private fun stopSpinSound() {
        if (isPlayingSound && streamId != 0) {
            soundPool.stop(streamId)
            isPlayingSound = false
            streamId = 0
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

@Composable
fun GyroscopeIndicator(x: Float, y: Float, acceleration: Float, modifier: Modifier = Modifier) {
    val animatedX by animateFloatAsState(targetValue = x, label = "AnimX")
    val animatedY by animateFloatAsState(targetValue = y, label = "AnimY")

    val hasTint = acceleration > 3f
    val targetColor = when {
        acceleration > 8f -> Color.Red
        acceleration > 3f -> Color.Yellow
        else -> Color.Transparent
    }

    val animatedColor by animateColorAsState(targetValue = targetColor, label = "ColorAnim")

    val targetSize = if (acceleration > 3f) 80.dp else 60.dp
    val animatedSize by animateDpAsState(targetValue = targetSize, label = "SizeAnim")

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "Fuerza de mov: ${String.format("%.1f", acceleration)}",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 80.dp)
        )

        Box(
            modifier = Modifier
                .size(300.dp)
                .border(width = 3.dp, color = Color.LightGray, shape = CircleShape)
        )

        Box(
            modifier = Modifier
                .size(10.dp)
                .background(Color.Red, shape = CircleShape)
        )

        Image(
            painter = painterResource(id = R.drawable.stell_ball),
            contentDescription = "Steel Ball Gyroscope",
            colorFilter = if (hasTint) ColorFilter.tint(animatedColor) else null,
            modifier = Modifier
                .offset(x = animatedX.dp, y = animatedY.dp)
                .size(animatedSize)
        )
    }
}

@Preview(showBackground = true)
@Composable
fun GyroscopeIndicatorPreview() {
    ActividadSensoresTheme {
        GyroscopeIndicator(x = 0f, y = 0f, acceleration = 0f)
    }
}